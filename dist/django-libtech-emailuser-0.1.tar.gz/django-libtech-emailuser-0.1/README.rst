django-libtech-emailuser
========================

Email as username in Django +1.5
